//
//  uploadCVC.swift
//  SnapShare
//
//  Created by Jo on 10/01/23.
//

import UIKit

class uploadCVC: UICollectionViewCell {
    
    @IBOutlet var imguploads: UIImageView!
}
