//
//  userprofleCVC.swift
//  SnapShare
//
//  Created by Jo on 27/01/23.
//

import UIKit

class proflefriendCVC: UICollectionViewCell {
    
    @IBOutlet var imgpic: UIImageView!
}
