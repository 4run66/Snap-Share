//
//  InterstCVC.swift
//  SnapShare
//
//  Created by Jo on 28/12/22.
//

import UIKit

class InterstCVC: UICollectionViewCell {
    

    @IBOutlet var lblinterst: UILabel!
    
}
