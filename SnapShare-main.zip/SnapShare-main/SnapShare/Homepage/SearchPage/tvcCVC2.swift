//
//  tvcCVC2.swift
//  SnapShare
//
//  Created by Jo on 29/12/22.
//

import UIKit

class tvcCVC2: UICollectionViewCell {
    
}
