//
//  tvcCVC3.swift
//  SnapShare
//
//  Created by Jo on 29/12/22.
//

import UIKit

class tvcCVC3: UICollectionViewCell {
    
    @IBOutlet var imgpost: UIImageView!
}
