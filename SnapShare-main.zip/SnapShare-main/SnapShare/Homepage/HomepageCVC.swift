//
//  HomepageCVC.swift
//  SnapShare
//
//  Created by Jo on 28/12/22.
//

import UIKit

class HomepageCVC: UICollectionViewCell {
    
    @IBOutlet var imgsnapUser: UIImageView!
    @IBOutlet var imgsnap: UIImageView!
}
