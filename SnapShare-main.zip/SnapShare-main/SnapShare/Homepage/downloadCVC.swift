//
//  downloadCVC.swift
//  SnapShare
//
//  Created by Jo on 29/12/22.
//

import UIKit

class downloadCVC: UICollectionViewCell {
    
    @IBOutlet var imggallery: UIImageView!
}

