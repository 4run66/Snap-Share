//
//  cvc1.swift
//  SnapShare
//
//  Created by Jo on 02/01/23.
//

import UIKit

class cvc1: UICollectionViewCell {
    
}
