//
//  Entity+CoreDataClass.swift
//  SnapShare
//
//  Created by Jo on 05/01/23.
//
//

import Foundation
import CoreData

@objc(Entity)
public class Entity: NSManagedObject {

}
